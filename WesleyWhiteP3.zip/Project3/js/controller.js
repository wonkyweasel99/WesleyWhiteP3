$(document).ready(function(){
   
    initValidation();
 
    //initialize any of your button or other event handlers 
    document.getElementById("visitB").addEventListener("click", loadVisitors);
});

let table = document.getElementById("visitorTable");

function loadVisitors() {
    showVisitors();
    renderTable(table, visitors);
    showList();
}
 
function submitForm() {
    idNum++
    let idNew = idNum;
    let id = idNew;
    let firstName = document.getElementById("first-name").value;
    let lastName = document.getElementById("last-name").value;
    let address = document.getElementById("address").value;
    let city = document.getElementById("city").value;
    let state = document.getElementById("state").value;
    let zip = document.getElementById("zip").value;
    let email = document.getElementById("email").value;
    let phone = document.getElementById("phone").value;
    let findOptions = {google: document.getElementById("google").value, friend: document.getElementById("friend").value, newspaper: document.getElementById("newspaper").value};
    let comment = document.getElementById("comment").value;
    let newVisitor = new Visitor(id, firstName, lastName, address, city, state, zip, phone, email, findOptions, comment);
    modelAddVisitor(newVisitor);
    renderTable(table, visitors);
    showList();
}
 
function addVisitor() {
    clearForm();
    showForm();
}
 
function deleteVisitor(id) {
    modelDeleteVisitor(id);
    renderTable(table,visitors);
    showList();
}