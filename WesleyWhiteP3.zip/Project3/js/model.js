class Visitor {
    constructor(id, firstName, lastName, address, city, state, zip, cellPhone, email, findOptions, comments) {
    this.id = id;
    this.firstName = firstName;
    this.lastName = lastName;
    this.address = address;
    this.city = city;
    this.state = state;
    this.zip = zip;
    this.cellPhone = cellPhone;
    this.email = email;
    this.findOptions = findOptions;
    this.comments = comments;
    }

    get fullName() {return this.firstName + " " + this.lastName;}

    get fullAddress() {return this.address + ", " +  this.city + " " + this.state + " " + this.zip;}

    idNum() {
        return this.id;
    }

}

let visitors = [ 
    new Visitor(1,"Ken","Jenson","1234 W. Main St.","Mapleton","UT","84664","801-444-5555","ken@gmail.com",{google:true,friend:false,newspaper:true}, "notes"),
    new Visitor(2,"Ben","Jenson","1234 W. Main St.","Mapleton","UT","84664","801-444-5555","ben@gmail.com",{google:true,friend:false,newspaper:false}, "notes"),
    new Visitor(3,"Michael","Jackson","5678 Shiny Glove Ln.","Las Vegas","NV","89131","702-877-1500","mj@heehee.net",{google:false,friend:false,newspaper:true}, "hee hee"),
    new Visitor(4,"Clark","Kent","12 Kryptonite Ave.","Smallville","KS","45677","111-111-1111","superman@bugle.net",{google:false,friend:false,newspaper:true},"lookin' good"),
    new Visitor(5,"Bruce","Wayne","100 Batcave Way","Gotham City","NJ","13455","314-159-2654","batlover@wayne.org",{google:true,friend:false,newspaper:false},"Justice")
   ];
var idNum = visitors.length;

function modelAddVisitor(visitor) {
    visitors.push(visitor);
}

function modelDeleteVisitor(id) {
        let index = findVisitorIndex(id);
        visitors.splice(index, 1);
        renderTable(table, visitors);
}

function findVisitor(id) {
    let visitLen = visitors.length;
    let i = 0;
    while(i<visitLen) {
        let visit = visitors[i];
        if(visit.idNum()==id) {
            return visit;
        }
        else {
            i++;
        }
    }
}

function findVisitorIndex(id) {
    let visitLen = visitors.length;
    let i = 0;
    while(i<visitLen) {
        let visit = visitors[i];
        if(visit.idNum()==id) {
            return i;
        }
        else {
            i++;
        }
    }
}
