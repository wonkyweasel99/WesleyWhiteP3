var HomeButton = document.getElementById("homeB");
var BioButton = document.getElementById("bioB");
var ScheduleButton = document.getElementById("scheduleB");
var LinksButton = document.getElementById("linksB");
var VisitButton = document.getElementById("visitB");
//var SubmitButton = document.getElementById("formSubmit");
var NewVisitorButton = document.getElementById("newVisitorB");
var CancelButton = document.getElementById("cancel");

var Home = document.getElementById("home");
var Bio = document.getElementById("bio");
var Schedule = document.getElementById("schedule");
var Links = document.getElementById("links");
var Visit = document.getElementById("visit");
var List = document.getElementById("visitorList");
var Form = document.getElementById("visitForm");
var Table = document.getElementById("visitorTable");

HomeButton.addEventListener("click", homeNav);
BioButton.addEventListener("click", bioNav);
ScheduleButton.addEventListener("click", scheduleNav);
LinksButton.addEventListener("click", linksNav);
VisitButton.addEventListener("click", showVisitors);
//SubmitButton.addEventListener("click", submitForm);
NewVisitorButton.addEventListener("click", addVisitor);
CancelButton.addEventListener("click", showList)

function homeNav() {
    Home.style.setProperty("display", "unset");
    Bio.style.setProperty("display", "none");
    Schedule.style.setProperty("display", "none")
    Links.style.setProperty("display", "none")
    Visit.style.setProperty("display", "none")
}

function bioNav() {
    Home.style.setProperty("display", "none");
    Bio.style.setProperty("display", "unset");
    Schedule.style.setProperty("display", "none")
    Links.style.setProperty("display", "none")
    Visit.style.setProperty("display", "none")
}

function scheduleNav() {
    Home.style.setProperty("display", "none");
    Bio.style.setProperty("display", "none");
    Schedule.style.setProperty("display", "unset")
    Links.style.setProperty("display", "none")
    Visit.style.setProperty("display", "none")
}

function linksNav() {
    Home.style.setProperty("display", "none");
    Bio.style.setProperty("display", "none");
    Schedule.style.setProperty("display", "none")
    Links.style.setProperty("display", "unset")
    Visit.style.setProperty("display", "none")
}

function showVisitors() {
    Home.style.setProperty("display", "none");
    Bio.style.setProperty("display", "none");
    Schedule.style.setProperty("display", "none")
    Links.style.setProperty("display", "none")
    Visit.style.setProperty("display", "unset")
    showList()
}

function renderTable(table, visitors) {
    let tableLength = table.rows.length;
    var tableReset = tableLength - 1; 
    while(tableReset > 0){
        table.deleteRow(-1);
        tableReset--;
    }

    let lenData = visitors.length;
    var i = 0;
    while(i < lenData) {
        let person = visitors[i];
        let row = table.insertRow();

        let nameCell = row.insertCell();
        let nameText = document.createTextNode(person.fullName);
        nameCell.appendChild(nameText);

        let addressCell = row.insertCell();
        let addressText = document.createTextNode(person.fullAddress);
        addressCell.appendChild(addressText);

        let phoneCell = row.insertCell();
        let phoneText = document.createTextNode(person.cellPhone);
        phoneCell.appendChild(phoneText);

        let emailCell = row.insertCell();
        let emailText = document.createTextNode(person.email);
        emailCell.appendChild(emailText);

        let idCell = row.insertCell();
        let idText = document.createTextNode(person.id);
        idCell.appendChild(idText);
        idCell.style.setProperty("display","none");

        let editCell = row.insertCell();
        let editText = document.createTextNode("Edit");
        editCell.appendChild(editText);
        editCell.id = i+1;
        editCell.addEventListener("click", function(){prompt("Editing Visitor "+editCell.id)})

        let deleteCell = row.insertCell();
        let deleteText = document.createTextNode("Delete");
        deleteCell.appendChild(deleteText);
        let visitorNum = i + 1;
        deleteCell.id = "visitor " + visitorNum;
        deleteCell.addEventListener("click", function(){
            var confirmation = prompt("Would you like to delete " + deleteCell.id + "? If so, enter 'yes'");
            if (confirmation == "yes"){
                modelDeleteVisitor(person.id);
            }
            });

        i++;
    
    }
}


function showList() {
    List.style.setProperty("display", "unset")
    Form.style.setProperty("display", "none")
}
function showForm() {
    List.style.setProperty("display", "none")
    Form.style.setProperty("display", "unset")
}

function clearForm() {
    document.getElementById("first-name").value = "";
    document.getElementById("last-name").value = "";
    document.getElementById("address").value = "";
    document.getElementById("city").value = "";
    document.getElementById("state").value = "";
    document.getElementById("zip").value = "";
    document.getElementById("email").value = "";
    document.getElementById("phone").value = "";
}